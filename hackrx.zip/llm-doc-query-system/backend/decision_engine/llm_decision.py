from openai import OpenAI
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def call_llm(query_data, clauses):
    """
    Call LLM to evaluate insurance claim based on policy clauses.
    """
    print("🔍 DEBUG: Starting LLM call...")
    
    prompt = f"""
    You are an insurance claim evaluator. Analyze the following claim request against the provided policy clauses and determine if the claim should be approved or rejected.

    CLAIM REQUEST:
    {query_data}

    RELEVANT POLICY CLAUSES:
    {clauses}

    CRITICAL EVALUATION RULES:
    1. FIRST CHECK WAITING PERIODS: If the policy duration is less than required waiting periods, REJECT the claim
    2. CHECK EXCLUSIONS: If the procedure is explicitly excluded, REJECT the claim
    3. CHECK POLICY CONDITIONS: If any policy conditions are not met, REJECT the claim
    4. ONLY APPROVE if ALL conditions are satisfied

    SPECIFIC WAITING PERIODS TO CHECK:
    - Cataracts: 24 months waiting period (policy duration must be >= 24 months)
    - Specified diseases/procedures: 24 months waiting period (policy duration must be >= 24 months)
    - Pre-existing diseases: 36 months waiting period (policy duration must be >= 36 months)
    - General waiting period: 30 days for new policies (policy duration must be >= 1 month)

    WAITING PERIOD LOGIC:
    - If policy_duration >= required_waiting_period: WAITING PERIOD MET (approve if other conditions met)
    - If policy_duration < required_waiting_period: WAITING PERIOD NOT MET (reject)
    - Example: 24 months policy duration meets 24 months waiting period requirement

    SPECIFIC EXCLUSIONS TO CHECK:
    - Cosmetic surgery (unless for reconstruction after accident/cancer)
    - Dental treatment (unless emergency due to accident)
    - Experimental treatments
    - Treatments outside policy coverage area

    EVALUATION PROCESS:
    1. Identify the procedure type
    2. Check if there's a waiting period requirement
    3. Compare policy duration with waiting period
    4. Check for any exclusions that apply
    5. Verify all policy conditions are met
    6. Make decision based on strict compliance

    IMPORTANT: Be STRICT about waiting periods and exclusions. If in doubt, REJECT the claim.

    Please provide your response in the following format:
    
    DECISION: [APPROVED/REJECTED]
    
    REASONING: [Detailed explanation with specific clause references. For rejections, clearly explain the specific waiting period, exclusion, or condition that was not met.]
    
    COVERAGE AMOUNT: [Specific amount in rupees if approved, 0 if rejected]
    
    RELEVANT CLAUSES: [List the specific clause numbers that support your decision]
    
    POLICY LIMITS: [Any sum insured or policy limits mentioned in the clauses]
    
    WAITING PERIOD CHECK: [State the waiting period requirement and whether it was met]
    """

    try:
        # Set OpenAI API key from environment variable
        api_key = os.getenv('OPENAI_API_KEY')
        print(f"🔍 DEBUG: API key found: {'Yes' if api_key else 'No'}")
        if api_key:
            print(f"🔍 DEBUG: API key starts with: {api_key[:10]}...")
        
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable not set")
        
        # Initialize OpenAI client with new API format
        client = OpenAI(api_key=api_key)
        print("🔍 DEBUG: OpenAI client initialized successfully")
        
        print("🔍 DEBUG: Making OpenAI API call...")
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1500,  # Increased for better justifications
            temperature=0.1
        )
        
        print("🔍 DEBUG: OpenAI API call successful")
        result = response.choices[0].message.content
        print(f"🔍 DEBUG: Response length: {len(result)} characters")
        
        return result
        
    except Exception as e:
        print(f"❌ Error in LLM call: {str(e)}")
        print(f"❌ Exception type: {type(e)}")
        import traceback
        print(f"❌ Full traceback: {traceback.format_exc()}")
        return f"Error calling LLM: {str(e)}"
