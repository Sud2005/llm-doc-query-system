def parse_query(query: str):
    # Dummy output; this will later use regex or an LLM
    return {
        "age": 46,
        "gender": "male",
        "procedure": "knee surgery",
        "location": "Pune",
        "policy_duration_months": 3
    }
