import faiss
import numpy as np

class VectorStore:
    def __init__(self, dimension):
        self.dimension = dimension
        self.index = faiss.IndexFlatL2(dimension)  # L2 = Euclidean distance
        self.text_chunks = []  # Keep text alongside vectors

    def add(self, embeddings, chunks):
        if len(embeddings) == 0:
            return
            
        vectors = np.array(embeddings).astype("float32")
        
        # Ensure vectors have the correct dimension
        if vectors.shape[1] != self.dimension:
            print(f"Warning: Embedding dimension {vectors.shape[1]} doesn't match expected {self.dimension}")
            # Pad or truncate if necessary
            if vectors.shape[1] < self.dimension:
                # Pad with zeros
                padding = np.zeros((vectors.shape[0], self.dimension - vectors.shape[1]))
                vectors = np.hstack([vectors, padding])
            else:
                # Truncate
                vectors = vectors[:, :self.dimension]
        
        self.index.add(vectors)
        self.text_chunks.extend(chunks)

    def search(self, query_embedding, top_k=3, distance_threshold=0.7):
        if len(self.text_chunks) == 0:
            return []
        query = np.array([query_embedding]).astype("float32")
        if query.shape[1] != self.dimension:
            if query.shape[1] < self.dimension:
                padding = np.zeros((query.shape[0], self.dimension - query.shape[1]))
                query = np.hstack([query, padding])
            else:
                query = query[:, :self.dimension]
        distances, indices = self.index.search(query, min(top_k, len(self.text_chunks)))
        # Only return chunks with distance below threshold (lower is better for L2)
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < len(self.text_chunks) and dist < distance_threshold:
                results.append(self.text_chunks[idx])
        return results
