# LLM Document Query System

This project uses Large Language Models (LLMs) to parse user queries and extract relevant clauses from unstructured documents like insurance policies.

## System Overview

The system now uses **LLM-based reasoning** instead of hardcoded rules to evaluate insurance claims. It:

1. **Reads and chunks** insurance policy documents
2. **Embeds** text chunks using sentence transformers
3. **Searches** for relevant clauses using semantic similarity
4. **Uses LLM reasoning** to evaluate claims based on retrieved clauses
5. **Provides detailed justifications** with specific policy references

## Modules
- Query Parser
- Document Reader
- Retriever & Embeddings
- **LLM Decision Engine** (NEW: Replaces hardcoded rules)
- Streamlit UI (optional)

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up OpenAI API key:
```bash
export OPENAI_API_KEY=your_api_key_here
```
Or create a `.env` file with:
```
OPENAI_API_KEY=your_api_key_here
```

3. Run the system:
```bash
python test_llm_system.py
```

## How It Works

1. **Document Processing**: PDFs are read, chunked, and embedded
2. **Semantic Search**: Queries are embedded and matched against policy chunks
3. **LLM Evaluation**: Retrieved chunks are sent to GPT-3.5-turbo for reasoning
4. **Structured Response**: LLM provides decision, reasoning, and clause references

## Example

For a cataract surgery claim with 24-month policy duration:
- System retrieves relevant policy clauses about cataracts and waiting periods
- LLM analyzes the clauses and determines if waiting period is satisfied
- Returns structured decision with detailed justification

## Key Improvements

- ✅ **No hardcoded rules** - Uses LLM reasoning
- ✅ **Detailed justifications** - References specific policy clauses
- ✅ **Flexible evaluation** - Can handle complex policy scenarios
- ✅ **Better accuracy** - LLM understands context and nuances
